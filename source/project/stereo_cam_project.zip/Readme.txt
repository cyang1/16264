Requirements: CMake >= 2.8, OpenCV >= 2.0

To compile the sources for your machine, go into the subdirectory of the
project you want to compile and type `cmake .` to generate the make system for
your operator system. Most of the time, the binary can be generated after this
by just calling `make`, but if you're on Windows and generated a Visual Studio
solution, then you must compile the project in Visual Studio.

It may also be necessary to change the following lines at the top of the
source files to the correct numbers for your current setup.

    #define LEFT_CAM 2
    #define RIGHT_CAM 1

Usually these will be 0 and 1, or 1 and 0, but if there are more than 2
webcams plugged in, then these numbers can vary. Trial and error to find the
correct numbers for these.