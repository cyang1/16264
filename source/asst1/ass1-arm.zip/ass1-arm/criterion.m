function f = criterion( x )
%CRITERION Specifies a function to minimize for fmincon to minimize
%   f : The output of the function to minimize.

global x_d;

% Draw the arm during each computation
draw(x);
pause(0.2);

pos = fk(x)';
f = dot(pos - x_d, pos - x_d);

end

