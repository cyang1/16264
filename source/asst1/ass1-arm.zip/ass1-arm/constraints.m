function [ c, ceq ] = constraints( x )
%CONSTRAINTS Specifies nonlinear inequality and equality constraints for
%the fmincon function that must be met at the end of the optimization.
%   c : Specifies the output of a function that must be <= 0.
%   ceq : Specifies the output of a function that must be equal to 0.

global x_d;

c = [];
ceq = fk(x) - x_d';

end

