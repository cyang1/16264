function [centroid, orientation] = get_blob_data( image_num )
% Returns the centroid and orientation of the block in rgba{image_num}.png
% and vdia{image_num}.

% Magic constants that seem to work best for thresholding.
RGB_THRESHOLD = 0.65;
DEPTH_THRESHOLD = 0.7;

rgb_filename = sprintf('rgba%d.png', image_num);
vdia_filename = sprintf('vdia%d', image_num);

rgba = imread(rgb_filename);
bw = im2bw(rgba, RGB_THRESHOLD);

% Get information about all blobs in image.
stats = regionprops(bw, 'Centroid', 'Orientation', 'Area');

% Get the data about the blob with the largest area.
[ max_area, idx_max_area ] = max([ stats.Area ]);
rgb_blob = stats(idx_max_area);

% Now load depth image.
vdia = read_vdi(vdia_filename);
depth = depth1(vdia);

% Segment depth image.
seg_depth = im2bw(depth, DEPTH_THRESHOLD);

% Get blobs in depth image.
stats_d = regionprops(seg_depth, 'Centroid', 'Orientation', 'MajorAxisLength', 'MinorAxisLength', 'Area');
 
% Find the depth blob with the closest centroid to the blob found with the
% rgb image.
centroids = cat(1, stats_d.Centroid);
distances = bsxfun(@minus, centroids, rgb_blob.Centroid);
normed = sum(cat(1, distances)'.^2);
 
[min_distance, idx_mindistance] = min(normed);
 
% The final blob we use is the one from the depth image.
blob = stats_d(idx_mindistance);

% Change Orientation to radians.
blob.Orientation = degtorad(blob.Orientation);

% For display purposes, draw the major and minor axes.
c = blob.Centroid;
l1 = blob.MajorAxisLength;
l2 = blob.MinorAxisLength;
majorAxisX(1) = c(1) - (l1 / 2) * cos(pi - blob.Orientation);
majorAxisY(1) = c(2) - (l1 / 2) * sin(pi - blob.Orientation);
majorAxisX(2) = c(1) + (l1 / 2) * cos(pi - blob.Orientation);
majorAxisY(2) = c(2) + (l1 / 2) * sin(pi - blob.Orientation);

minorAxisX(1) = c(1) - (l2 / 2) * cos(pi/2 - blob.Orientation);
minorAxisY(1) = c(2) - (l2 / 2) * sin(pi/2 - blob.Orientation);
minorAxisX(2) = c(1) + (l2 / 2) * cos(pi/2 - blob.Orientation);
minorAxisY(2) = c(2) + (l2 / 2) * sin(pi/2 - blob.Orientation);

% Display the axes along with a * at the centroid.
% Overlay the depth segmentation on the rgb image.
figure, imshow(rgba);
hold on;
h = imshow(seg_depth);
set(h, 'AlphaData', zeros(size(h)) + 0.4);
plot(c(:,1),c(:,2),'*','Color','green');
plot(majorAxisX, majorAxisY, 'Color', 'blue');
plot(minorAxisX, minorAxisY, 'Color', 'red');

% Return the important information.
centroid = blob.Centroid;
orientation = blob.Orientation;

end
